

var bio = {
    "name" : "Nicholas McTaggart",
    "age" : "25",
    "role" : " Sr. Network-Specialist",
    "pic" : "images/genie.jpg",
    "skills" : ["Data Analysis,", " Excel Reporting and automation,", " Process creation and documentation", "Isolation Troubleshooting"],
"contacts": {
    "email" : "NicholasMcT@hotmail.com",
    "phone" : "469-601-7905",
    "github" : "roostercogburn",
    "location" : ["Terrell, Tx"],
    "welcomeMessage" : "  Hello, my name is Nicholas McTaggart, my current goal in life is to become well versed in programming languages, and my end goal in life is to be an expert in cyber security. I enjoy spending time with my family and expanding my intelect in multiple subjects. I work hard, and make it a point to be punctual. My favorite motto is: want to beats can do when can do don't want to."
  }
}

var formattedPic = HTMLbioPic.replace("%data%", (bio.pic));
$("#header").append(formattedPic);

var formattedwelcomeMSG = HTMLwelcomeMsg.replace("%data%",(bio.contacts.welcomeMessage));
$("#header").append(formattedwelcomeMSG);

var formattedGithub = HTMLgithub.replace("%data%", (bio.contacts.github));
var formattedEmail = HTMLemail.replace("%data%", (bio.contacts.email));
var formattedPhone = HTMLmobile.replace("%data%", (bio.contacts.phone));
  $("#topContacts").prepend(formattedGithub);
  $("#topContacts").prepend(formattedEmail);
  $("#topContacts").prepend(formattedPhone);
  $("#lets-connect").append(formattedPhone);
  $("#lets-connect").append(formattedEmail);
  $("#lets-connect").append(formattedGithub);

if(bio.skills.length > 0) {

$("#header").append(HTMLskillsStart);

 var formattedSkill = HTMLskills.replace("%data%", bio.skills[0]);
  $("#skills").append(formattedSkill);
  formattedSkill = HTMLskills.replace("%data%",bio.skills[1]);
  $("#skills").append(formattedSkill);
  formattedSkill = HTMLskills.replace("%data%",bio.skills[2]);
  $("#skills").append(formattedSkill);
  formattedSkill = HTMLskills.replace("%data%",bio.skills[3]);
  $("#skills").append(formattedSkill);
}

var formattedName = HTMLheaderName.replace("%data%", (bio.name));
var formattedRole = HTMLheaderRole.replace("%data%", (bio.role));
$("#header").prepend(formattedRole);
$("#header").prepend(formattedName);

var work = {
	"jobs": [{
			"position": "Technical Support Operations",
			"employer": "AT&T Digital Life",
			"years": "2015 - present",
			"description": "Provide documentation and processes for frontline support along with troubleshooting real-time issues.",
			"location": ["Richardson, Tx"]
		},
		{
			"position": "Executive Operations Manager",
			"employer": "AT&T Digital Life",
			"years": "2014 - 2015",
			"description": "Supervised appointments at Executive and VIP's homes. Provided Technical Support for executives and technicians.Developed and maintained the chronic issue reporting.",
			"location": "Richardson, Tx"
		},
		{
			"position": "Monitoring Specialist",
			"employer": "AT&T Digital Life",
			"years": "2013 - 2014",
			"description": "Reached out to customers in regards to Digita Life Alarms. Worked real-time support for customers via live chat.",
			"location": ["Farmers Branch, Tx"]
		},
		{
			"position": "IT Technician",
			"employer": "Pheonix Charter School",
			"years": "2012 - 2013",
			"description": "Repaired Hardware and Software on computers. Physically connected servers and routers",
			"location": ["Greenville, Tx"]
		},
		{
			"position": "U-Verse Premise Technician",
			"employer": "AT&T U-Verse",
			"years": "2012 - 2012",
			"description": "Installed and repaired U-Verse including INIDs. Used Isolation Troubleshooting for the U-Verse network",
			"location": ["Dallas, Tx"]
		},
		{
			"position": "Assistant Produce Manager",
			"employer": "Brookshires",
			"years": "2009 - 2012",
			"description": "Provide documentation and processes for frontline support along with troubleshooting real-time issues.",
			"location": ["Terrell, Tx"]
		}
	]
}

for (job in work.jobs) {
  $("#workExperience").append(HTMLworkStart);
  var formattedEmployer = HTMLworkEmployer.replace("%data%",work.jobs[job].employer);
  var formattedTitle = HTMLworkTitle.replace("%data%",work.jobs[job].position);
  var formattedEmployerTitle = formattedEmployer + formattedTitle;
  $(".work-entry:last").append(formattedEmployerTitle);

  var formattedDates = HTMLworkDates.replace("%data%",work.jobs[job].years);
  var formattedDescription = HTMLworkDescription.replace("%data%",work.jobs[job].description);
  $(".work-entry:last").append(formattedDates);
  $(".work-entry:last").append(formattedDescription);
}

var projects = {
	"project": [{
    "title": "Intro to Programming nanodegree",
    "description": "Introduction to the basics of programming",
    "years": " 2017 - 2017",
    "location": " Dallas, Tx",
    "image": "images/udacity.jpg"
    }
  ]
}

for (project in projects.project) {
  $("#projects").append(HTMLprojectStart);
  var formattedprojectTitle = HTMLprojectTitle.replace("%data%",projects.project[project].title);
  var formattedprojectDescription = HTMLprojectDescription.replace("%data%",projects.project[project].description);
  var formattedprojectYears = HTMLprojectDates.replace("%data%",projects.project[project].years);
  var formattedprojectTitleYears = formattedprojectTitle + formattedprojectYears;
  $(".project-entry:last").append(formattedprojectTitleYears);
  $(".project-entry:last").append(formattedprojectDescription);
  var formattedprojectPic = HTMLprojectImage.replace("%data%", (projects.project[project].image));
  $(".project-entry:last").append(formattedprojectPic);

}

var education = {
	"schools": [{
    "name": "Poetry Community Christian School",
    "degree": "High School Diploma",
    "years": "2007 - 2010",
    "location": " Poetry, TX",
    }
  ]
}

for (school in education.schools) {
  $("#education").append(HTMLschoolStart);
  var formattedschoolName = HTMLschoolName.replace("%data%",education.schools[school].name);
  var formattedDegree = HTMLschoolDegree.replace("%data%",education.schools[school].degree);
  var formattedschoolYears = HTMLschoolDates.replace("%data%",education.schools[school].years);
  var formattedschoolNameYears = formattedschoolName + formattedschoolYears;
  $(".education-entry:last").append(formattedDegree);
  $(".education-entry:last").append(formattedschoolYears);
  $(".education-entry:last").prepend(formattedschoolName);
}

//map for locations
{
$("#mapDiv").append(googleMap);
}
