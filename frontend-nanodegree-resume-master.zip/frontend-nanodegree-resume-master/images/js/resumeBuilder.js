
//defintes bio and what it contains
var bio = {
    "name" : "Nicholas McTaggart",
    "age" : "25",
    "role" : " Sr. Network-Specialist",
    "pic" : "images/genie.jpg",
    "skills" : ["Data Analysis,", " Excel Reporting and automation,", " Process creation and documentation", "Isolation Troubleshooting"],
"contacts": {
    "email" : "NicholasMcT@hotmail.com",
    "phone" : "469-601-7905",
    "github" : "roostercogburn",
    "location" : ["Terrell, Tx"],
    "welcomeMessage" : "  Hello, my name is Nicholas McTaggart, my current goal in life is to become well versed in programming languages, and my end goal in life is to be an expert in cyber security. I enjoy spending time with my family and expanding my intelect on multiple topics. I work hard, and make it a point to be punctual. My favorite motto is: want to beats can do when can do don't want to."
  }
}
//formats the biopic with the help of helper.js and then appends it to the header
var formattedPic = HTMLbioPic.replace("%data%", (bio.pic));
$("#header").append(formattedPic);
//formats the welcome message with the help of helper.js and then appends it to the header
var formattedwelcomeMSG = HTMLwelcomeMsg.replace("%data%",(bio.contacts.welcomeMessage));
$("#header").append(formattedwelcomeMSG);
//formats the contacts with the help of helper.js and then appends it to the top contacts and the lets-connect section
var formattedGithub = HTMLgithub.replace("%data%", (bio.contacts.github));
var formattedEmail = HTMLemail.replace("%data%", (bio.contacts.email));
var formattedPhone = HTMLmobile.replace("%data%", (bio.contacts.phone));
  $("#topContacts").prepend(formattedGithub);
  $("#topContacts").prepend(formattedEmail);
  $("#topContacts").prepend(formattedPhone);
  $("#lets-connect").append(formattedPhone);
  $("#lets-connect").append(formattedEmail);
  $("#lets-connect").append(formattedGithub);

//pulls the skills from the bio section formatts them with the assistance of helper.js and appends it to h3
if(bio.skills.length > 0) {

$("#header").append(HTMLskillsStart);

 var formattedSkill = HTMLskills.replace("%data%", bio.skills[0]);
  $("#skills").append(formattedSkill);
  formattedSkill = HTMLskills.replace("%data%",bio.skills[1]);
  $("#skills").append(formattedSkill);
  formattedSkill = HTMLskills.replace("%data%",bio.skills[2]);
  $("#skills").append(formattedSkill);
  formattedSkill = HTMLskills.replace("%data%",bio.skills[3]);
  $("#skills").append(formattedSkill);
}
//formats name and role using helper. js and then it prepends it in the proper section of the header
var formattedName = HTMLheaderName.replace("%data%", (bio.name));
var formattedRole = HTMLheaderRole.replace("%data%", (bio.role));
$("#header").prepend(formattedRole);
$("#header").prepend(formattedName);

//defines the work section
var work = {
	"jobs": [{
			"position": "Technical Support Operations",
			"employer": "AT&T Digital Life",
			"years": "2015 - present",
			"description": "Provide documentation and processes for frontline support along with troubleshooting real-time issues.",
			"location": ["Richardson, Tx"]
		},
		{
			"position": "Executive Operations Manager",
			"employer": "AT&T Digital Life",
			"years": "2014 - 2015",
			"description": "Supervised appointments at Executive and VIP's homes. Provided Technical Support for executives and technicians.Developed and maintained the chronic issue reporting.",
			"location": "Richardson, Tx"
		},
		{
			"position": "Monitoring Specialist",
			"employer": "AT&T Digital Life",
			"years": "2013 - 2014",
			"description": "Reached out to customers in regards to Digita Life Alarms. Worked real-time support for customers via live chat.",
			"location": ["Farmers Branch, Tx"]
		},
		{
			"position": "IT Technician",
			"employer": "Pheonix Charter School",
			"years": "2012 - 2013",
			"description": "Repaired Hardware and Software on computers. Physically connected servers and routers",
			"location": ["Greenville, Tx"]
		},
		{
			"position": "U-Verse Premise Technician",
			"employer": "AT&T U-Verse",
			"years": "2012 - 2012",
			"description": "Installed and repaired U-Verse including INIDs. Used Isolation Troubleshooting for the U-Verse network",
			"location": ["Dallas, Tx"]
		},
		{
			"position": "Assistant Produce Manager",
			"employer": "Brookshires",
			"years": "2009 - 2012",
			"description": "Provide documentation and processes for frontline support along with troubleshooting real-time issues.",
			"location": ["Terrell, Tx"]
		}
	]
}
//defines the parts of the JSON file, formats them with the help of the helper.js file and appends them in the work-entry section.
jobs.display = function(){
  if(work.jobs.length > 0){
  for(job in work.jobs){
    $("#workExperience").append(HTMLworkStart);
    var formattedEmployer = HTMLworkEmployer.replace("%data%",work.jobs[job].employer);
    var formattedTitle = HTMLworkTitle.replace("%data%",work.jobs[job].position);
    var formattedEmployerTitle = formattedEmployer + formattedTitle;
    $(".work-entry:last").append(formattedEmployerTitle);

    var formattedDates = HTMLworkDates.replace("%data%",work.jobs[job].years);
    var formattedDescription = HTMLworkDescription.replace("%data%",work.jobs[job].description);
    $(".work-entry:last").append(formattedDates);
    $(".work-entry:last").append(formattedDescription);
    }
  }
}
//defines the projects
var projects = {
	"project": [{
    "title": "Intro to Programming nanodegree",
    "description": "Introduction to the basics of programming",
    "years": " 2017 - 2017",
    "location": " Dallas, Tx",
    "image": "images/udacity.jpg"
    }
  ]
}
//defines the parts of the JSON file, formats them with the help of the helper.js file and appends them in the projects-entry section.
project.display = function(){
  if(projects.project.length > 0){
  for(project in projects.project){
    $("#projects").append(HTMLprojectStart);
      var formattedprojectTitle = HTMLprojectTitle.replace("%data%",projects.project[project].title);
      var formattedprojectDescription = HTMLprojectDescription.replace("%data%",projects.project[project].description);
      var formattedprojectYears = HTMLprojectDates.replace("%data%",projects.project[project].years);
      var formattedprojectTitleYears = formattedprojectTitle + formattedprojectYears;
      $(".project-entry:last").append(formattedprojectTitleYears);
      $(".project-entry:last").append(formattedprojectDescription);
      var formattedprojectPic = HTMLprojectImage.replace("%data%", (projects.project[project].image));
      $(".project-entry:last").append(formattedprojectPic);
    }
  }
}
//defines the education field and what it contains
var education = {
	"schools": [{
    "name": "Poetry Community Christian School",
    "degree": "High School Diploma",
    "years": "2007 - 2010",
    "location": " Poetry, TX",
    }
  ]
}
//defines the parts of the JSON file, formats them with the help of the helper.js file and appends them in the education-entry section.
education.display = function(){
  if(education.school.length > 0){
  for(school in education.schools){
    $("#education").append(HTMLschoolStart);
      var formattedschoolName = HTMLschoolName.replace("%data%",education.schools[school].name);
      var formattedDegree = HTMLschoolDegree.replace("%data%",education.schools[school].degree);
      var formattedschoolYears = HTMLschoolDates.replace("%data%",education.schools[school].years);
      var formattedschoolNameYears = formattedschoolName + formattedschoolYears;
      $(".education-entry:last").append(formattedDegree);
      $(".education-entry:last").append(formattedschoolYears);
      $(".education-entry:last").prepend(formattedschoolName);
    }
  }
}
education.display();
project.display();
jobs.display();
//map for locations
{
$("#mapDiv").append(googleMap);
}


//Udacity.com was used for methods of both formatting code and writing code
